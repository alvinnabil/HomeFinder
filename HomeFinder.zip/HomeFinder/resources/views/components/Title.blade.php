<nav class="navbar fixed-top border-bottom px-3 bg-light" style="height: 76px;">
    <div class="d-flex justify-content-start align-items-center h-100">
        <a href="/" class="fs-5 ms-3 fw-bolder text-decoration-none text-dark">Home<span class="text-primary">Finder</span></a>
    </div>
</nav>