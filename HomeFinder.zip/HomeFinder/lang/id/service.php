<?php

return [
    'title' => 'Layanan Kami',
    'subtitle' => 'Semua yang Anda butuhkan untuk menemukan, membeli, dan mengelola properti dengan mudah dan percaya diri.',

    'cta_title' => 'Masih menunggu apa?',
    'cta_desc' => 'Mulai jelajahi listing kami dan ambil langkah menuju properti impian Anda.',
    'cta_button' => 'Lihat Properti',
];
