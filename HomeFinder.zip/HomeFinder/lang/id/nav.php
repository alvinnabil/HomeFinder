<?php

// nav
return [
    'properties' => 'Properti',
    'services' => 'Layanan',
    'about' => 'Tentang',
    'contact' => 'Kontak',
    'favorite' => 'Favorit',

    'sign_in' => 'Masuk',
    'get_started' => 'Daftar',
    'logout' => 'Keluar',
];
