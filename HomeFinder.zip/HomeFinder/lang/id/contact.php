<?php

return [
    'title' => 'Hubungi Kami',
    'subtitle' => 'Punya pertanyaan atau butuh bantuan? Kirim pesan kepada kami.',

    'success' => 'Pesan Anda berhasil dikirim.',
    
    'name_label' => 'Nama Lengkap',
    'name_placeholder' => 'Nama lengkap Anda',

    'email_label' => 'Email',
    'email_placeholder' => 'email@anda.com',

    'message_label' => 'Pesan',
    'message_placeholder' => 'Apa yang bisa kami bantu?',

    'button' => 'Kirim Pesan',
];
