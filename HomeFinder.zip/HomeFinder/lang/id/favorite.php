<?php

return [
    'title' => 'Favorit Saya',
    'subtitle' => 'Berikut adalah properti yang telah Anda tambahkan ke favorit',

    'price_label' => 'Harga',

    'remove' => 'Hapus',
    'view' => 'Lihat',

    'empty' => 'Anda belum memiliki properti favorit.',
];
