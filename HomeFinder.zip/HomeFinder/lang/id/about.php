<?php

return [
    'title' => 'Tentang HomeFinder',

    'intro_1' => 'HomeFinder adalah platform properti modern yang dirancang untuk membantu
    orang menemukan, membeli, dan mengelola properti dengan percaya diri.',

    'intro_2' => 'Kami menyederhanakan perjalanan properti dengan menghubungkan pengguna
    dengan listing terverifikasi, informasi transparan, dan profesional terpercaya.',
];
