<?php

return [
    'owner' => 'Pemilik',

    'total_area' => 'Luas Total',
    'bedrooms' => 'Kamar Tidur',
    'bathrooms' => 'Kamar Mandi',

    'purchase' => 'Beli Properti Ini',

    'add_favorite' => 'Tambah ke Favorit',
    'remove_favorite' => 'Hapus dari Favorit',
    'login_favorite' => 'Login untuk menambah favorit',

    'summary' => 'Ringkasan',

    'dimension' => 'Dimensi',
    'total_size' => 'Luas Total',
    'rating' => 'Rating',

    'location' => 'Lokasi',
];
