<?php

return [
    'title' => 'My Favorites',
    'subtitle' => 'Here are the properties you have added to your favorites',

    'price_label' => 'Price',

    'remove' => 'Remove',
    'view' => 'View',

    'empty' => "You don't have any favorite properties yet.",
];
