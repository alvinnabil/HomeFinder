<?php

return [
    'owner' => 'Owner',

    'total_area' => 'Total Area',
    'bedrooms' => 'Bedrooms',
    'bathrooms' => 'Bathrooms',

    'purchase' => 'Purchase this Property',

    'add_favorite' => 'Add to Favorite',
    'remove_favorite' => 'Remove from Favorite',
    'login_favorite' => 'Login to add favorite',

    'summary' => 'Summary',

    'dimension' => 'Dimension',
    'total_size' => 'Total Size',
    'rating' => 'Rating',

    'location' => 'Location',
];
