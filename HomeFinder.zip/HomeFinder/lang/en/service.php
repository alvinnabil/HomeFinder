<?php

return [
    'title' => 'Our Services',
    'subtitle' => 'Everything you need to discover, purchase, and manage properties with confidence and ease.',

    'cta_title' => 'So what are you waiting for?',
    'cta_desc' => 'Start exploring our listings and take the next step toward your ideal property.',
    'cta_button' => 'Browse Properties',
];
