<?php

// nav
return [
    'properties' => 'Properties',
    'services' => 'Services',
    'about' => 'About',
    'contact' => 'Contact',
    'favorite' => 'Favorite',

    'sign_in' => 'Sign In',
    'get_started' => 'Get Started',
    'logout' => 'Logout',
];

